const result = document.getElementById('result');
const buttons = document.querySelectorAll('button');

buttons.forEach(button => {
  button.addEventListener('click', () => {
    const buttonValue = button.textContent;

    if (buttonValue === '=') {
      try {
        result.value = eval(result.value);
      } catch (error) {
        result.value = 'Error';
      }
    } else if (buttonValue === 'AC') {
      result.value = '';
    } else if (buttonValue === 'DEL') {
      result.value = result.value.slice(0, -1);
    }
    else if (button.textContent === '+/-') {
        result.value = -result.value;
      }  else {
      result.value += buttonValue;
    }
  });
});